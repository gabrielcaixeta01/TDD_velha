// Copyright [2024] Gabriel Caixeta

#ifndef VELHA_HPP_
#define VELHA_HPP_

int VerificaVelha(const int tabuleiro[3][3]);

#endif  // VELHA_HPP_
